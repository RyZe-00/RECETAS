class RecipesController < ApplicationController
  before_action :authenticate_user!, only: [:new, :edit, :create, :update, :destroy]
  before_action :set_recipe, only: [:show, :edit, :update, :destroy]

  before_action :authenticate_user!, only: [:toggle_favorite]

  def toggle_favorite
    @recipe = Recipe.find(params[:id])
    if current_user.favorite_recipes.include?(@recipe)
      current_user.favorite_recipes.delete(@recipe)
      flash[:notice] = "Recipe removed from favorites."
    else
      current_user.favorite_recipes << @recipe
      flash[:notice] = "Recipe added to favorites."
    end
    redirect_to @recipe
  end

  # GET /recipes or /recipes.json
  def index
    @q = Recipe.ransack(params[:q])
    @recipes = @q.result(distinct: true)
  end


  # GET /recipes/1 or /recipes/1.json
  def show
  end

  # GET /recipes/new
  def new
    @recipe = current_user.recipes.build
  end

  # GET /recipes/1/edit
  def edit
    unless current_user == @recipe.user
      redirect_to @recipe, alert: "No tienes permiso para editar esta receta."
    end
  end

  # POST /recipes or /recipes.json
  def create
    @recipe = current_user.recipes.build(recipe_params)
    @recipe.tag_list.add(params[:recipe][:tag_list], parse: true) # Agrega las etiquetas proporcionadas por el usuario

    if @recipe.save
      redirect_to @recipe, notice: "Recipe was successfully created."
    else
      render :new, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /recipes/1 or /recipes/1.json
  def update
    if current_user == @recipe.user
      @recipe.tag_list.add(params[:recipe][:tag_list], parse: true) # Agrega las etiquetas proporcionadas por el usuario
      if @recipe.update(recipe_params)
        redirect_to @recipe, notice: "Recipe was successfully updated."
      else
        render :edit, status: :unprocessable_entity
      end
    else
      redirect_to @recipe, alert: "No tienes permiso para editar esta receta."
    end
  end

  # DELETE /recipes/1 or /recipes/1.json
  def destroy
    if current_user == @recipe.user
      # Eliminar comentarios asociados a la receta
      Comment.where(recipe_id: @recipe.id).destroy_all

      # Eliminar registros de favoritos asociados a la receta
      Favorite.where(recipe_id: @recipe.id).destroy_all

      # Finalmente, eliminar la receta
      @recipe.destroy
      redirect_to recipes_url, notice: "Recipe was successfully destroyed."
    else
      redirect_to @recipe, alert: "No tienes permiso para eliminar esta receta."
    end
  end


  private

  # Use callbacks to share common setup or constraints between actions.
  def set_recipe
    @recipe = Recipe.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def recipe_params
    params.require(:recipe).permit(:title, :ingredients, :instructions, :user_id)
  end
end
