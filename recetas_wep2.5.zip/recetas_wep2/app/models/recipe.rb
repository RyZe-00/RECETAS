class Recipe < ApplicationRecord
  belongs_to :user
  has_many :favorites
  has_many :favorited_by, through: :favorites, source: :user
  has_many :comments
  acts_as_taggable_on :tags

  def self.ransackable_attributes(auth_object = nil)
    ["title", "ingredients", "instructions"] # Agrega los atributos que deseas permitir que Ransack busque
  end

  # Configuración para la búsqueda con Ransack
  def self.search(params)
    recipes = self.all
    if params[:q].present?
      recipes = recipes.ransack(params[:q]).result
    else
      recipes
    end
  end
end
