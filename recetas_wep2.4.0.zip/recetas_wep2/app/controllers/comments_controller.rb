class CommentsController < ApplicationController
  before_action :authenticate_user!

  def create
    @recipe = Recipe.find(params[:recipe_id])
    @comment = @recipe.comments.build(comment_params)
    @comment.user = current_user
    if @comment.save
      redirect_to @recipe, notice: "Comentario agregado correctamente."
    else
      render 'recipes/show'
    end
  end

  def destroy
    @comment = Comment.find(params[:id])
    @comment.destroy
    redirect_to @comment.recipe, notice: "Comentario eliminado correctamente."
  end

  private

  def comment_params
    params.require(:comment).permit(:body)
  end

end
