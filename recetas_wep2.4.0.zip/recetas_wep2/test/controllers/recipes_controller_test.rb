require "test_helper"

class RecipesControllerTest < ActionDispatch::IntegrationTest

end
