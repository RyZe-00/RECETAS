require "test_helper"

class CommentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  def setup
    @user = users(:one) # Asegúrate de tener al menos un usuario definido en tus fixtures
    @recipe = recipes(:one) # Asegúrate de tener al menos una receta definida en tus fixtures
    @comment = Comment.new(body: "Este es un comentario", recipe: @recipe, user: @user)
  end

  test "el cuerpo debe ser valido" do
    @comment.body = "     "
    assert_not @comment.valid?
  end

  test "El user ID debe ser valido" do
    @comment.user_id = nil
    assert_not @comment.valid?
  end

  test "El recipe ID debe ser valido" do
    @comment.recipe_id = nil
    assert_not @comment.valid?
  end

end
