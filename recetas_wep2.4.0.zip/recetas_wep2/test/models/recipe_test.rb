require "test_helper"

class RecipeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  def setup
    @user = users(:one) # Asegúrate de tener definido al menos un usuario en tu archivo fixtures
    @recipe = Recipe.new(title: "Example Recipe", ingredients: "Ingredient 1, Ingredient 2", instructions: "Step 1, Step 2", user: @user)
  end

  test "receta valida" do
    assert @recipe.valid?
  end

  test "El titulo debe estar presente" do
    @recipe.title = "     "
    assert_not @recipe.valid?
  end

  test "Ingrediente debe estar presente" do
    @recipe.ingredients = "     "
    assert_not @recipe.valid?
  end

  test "Intrucciones debe estar presente" do
    @recipe.instructions = "     "
    assert_not @recipe.valid?
  end

  test "User ID debe estar presente" do
    @recipe.user_id = nil
    assert_not @recipe.valid?
  end

  test "Los comentarios asociados deben ser destruidos" do
    @recipe.save
    @recipe.comments.create!(body: "Lorem ipsum", user: @user)
    assert_difference 'Comment.count', -1 do
      @recipe.destroy
    end
  end

  test "Los favoritos asociados deben ser destruidos" do
    @recipe.save
    @recipe.favorites.create!(user: @user)
    assert_difference 'Favorite.count', -1 do
      @recipe.destroy
    end
  end

end
