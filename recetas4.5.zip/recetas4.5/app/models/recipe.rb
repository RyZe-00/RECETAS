class Recipe < ApplicationRecord
  belongs_to :user
  has_many :comments, dependent: :destroy

  def self.ransackable_attributes(auth_object = nil)
    ["title", "ingredients", "category", "preparation_time"]
  end

  def self.ransackable_associations(auth_object = nil)
    ["comments", "user"]
  end

end
