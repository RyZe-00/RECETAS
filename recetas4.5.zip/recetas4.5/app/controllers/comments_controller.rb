# app/controllers/comments_controller.rb
class CommentsController < ApplicationController
  def create
    @recipe = Recipe.find(params[:id])
    @comment = @recipe.comments.build(comment_params)
    @comment.user = current_user
    if @comment.save
      redirect_to @recipe, notice: 'Comment was successfully created.'
    else
      render 'recipes/show' # Esto renderiza la vista de la receta donde ocurrió el error
    end
  end

  private

  def comment_params
    params.require(:comment).permit(:content)
  end
end
