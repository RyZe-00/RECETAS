class RecipesController < ApplicationController
  before_action :authenticate_user!, only: [:new, :edit, :create, :update, :destroy]
  before_action :set_recipe, only: [:show, :edit, :update, :destroy]

  # GET /recipes or /recipes.json
  #def index
  #  @recipes = Recipe.all
  #end
  def self.ransackable_attributes(auth_object = nil)
    ["title", "ingredients"]
  end

  def index
    @q = Recipe.ransack(params[:q])
    @recipes = @q.result(distinct: true)
  end

  # GET /recipes/1 or /recipes/1.json
  def show
    @recipe = Recipe.find(params[:id])
    @comment = @recipe.comments.build
    @comments = @recipe.comments
  end

  def create_comment
    @recipe = Recipe.find(params[:id])
    @comment = @recipe.comments.build(comment_params)
    @comment.user = current_user
    if @comment.save
      redirect_to recipe_path(@recipe), notice: 'Comment was successfully created.'
    else
      @comments = @recipe.comments
      render 'show'
    end
  end

  private

  def comment_params
    params.require(:comment).permit(:content)
  end

  # GET /recipes/new
  def new
    @recipe = current_user.recipes.build
  end

  # GET /recipes/1/edit
  def edit
    unless current_user == @recipe.user
      redirect_to @recipe, alert: "No tienes permiso para editar esta receta."
    end
  end

  # POST /recipes or /recipes.json
  def create
    @recipe = current_user.recipes.build(recipe_params)

    if @recipe.save
      redirect_to @recipe, notice: "Recipe was successfully created."
    else
      render :new, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /recipes/1 or /recipes/1.json
  def update
    if current_user == @recipe.user
      if @recipe.update(recipe_params)
        redirect_to @recipe, notice: "Recipe was successfully updated."
      else
        render :edit, status: :unprocessable_entity
      end
    else
      redirect_to @recipe, alert: "No tienes permiso para editar esta receta."
    end
  end

  # DELETE /recipes/1 or /recipes/1.json
  def destroy
    if current_user == @recipe.user
      @recipe.destroy
      redirect_to recipes_url, notice: "Recipe was successfully destroyed."
    else
      redirect_to @recipe, alert: "No tienes permiso para eliminar esta receta."
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_recipe
    @recipe = Recipe.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def recipe_params
    params.require(:recipe).permit(:title, :ingredients, :instructions, :user_id)
  end
end
