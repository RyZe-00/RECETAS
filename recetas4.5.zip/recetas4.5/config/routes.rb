Rails.application.routes.draw do
  devise_for :users

  root 'recipes#index'

  resources :recipes do
    # No es necesario definir la ruta create_comment aquí
  end

  # Define la ruta para crear un comentario fuera del bloque resources :recipes

  post 'recipes/:id/create_comment', to: 'recipes#create_comment', as: 'create_comment_recipe'

end
